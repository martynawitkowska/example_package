def add_one(number: int) -> int:
    return number + 1
